import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { ImageDisplay } from './components/ImageDisplay';
import { editImageWithPrompt } from './services/geminiService';
import { fileToBase64 } from './utils/fileUtils';
import { PromptExamples } from './components/PromptExamples';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImagePreview, setOriginalImagePreview] = useState<string | null>(null);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (file: File) => {
    setOriginalImage(file);
    setEditedImage(null);
    setError(null);
    setOriginalImagePreview(URL.createObjectURL(file));
  };

  const handleSelectPrompt = (example: string) => {
    setPrompt(example);
  };

  const handleSubmit = useCallback(async () => {
    if (!originalImage || !prompt) {
      setError("Per favore, carica un'immagine e inserisci una descrizione per la modifica.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setEditedImage(null);

    try {
      const { data, mimeType } = await fileToBase64(originalImage);
      const resultImageUrl = await editImageWithPrompt(data, mimeType, prompt);
      setEditedImage(resultImageUrl);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Si è verificato un errore sconosciuto. Riprova più tardi.');
    } finally {
      setIsLoading(false);
    }
  }, [originalImage, prompt]);

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-slate-800 rounded-2xl shadow-2xl p-6 md:p-8 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
              <ImageUploader onImageUpload={handleImageUpload} imagePreviewUrl={originalImagePreview} />
              
              <div className="space-y-6 flex flex-col h-full">
                <div className="flex-grow">
                  <label htmlFor="prompt" className="block text-sm font-medium text-slate-300 mb-2">
                    2. Descrivi la trasformazione
                  </label>
                  <textarea
                    id="prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Es: 'arredamento in stile scandinavo con divano in tessuto chiaro, tavolino in legno e molte piante'"
                    rows={4}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg p-3 text-white placeholder-slate-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-200"
                    disabled={isLoading}
                  />
                   <PromptExamples onSelectPrompt={handleSelectPrompt} disabled={isLoading} />
                </div>
                
                <button
                  onClick={handleSubmit}
                  disabled={isLoading || !originalImage || !prompt}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center"
                >
                  {isLoading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Trasformazione in corso...
                    </>
                  ) : 'Trasforma Immagine'}
                </button>
              </div>
            </div>
            
            {error && <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">{error}</div>}
          </div>

          <ImageDisplay
            originalImage={originalImagePreview}
            editedImage={editedImage}
            isLoading={isLoading}
          />
        </div>
      </main>
    </div>
  );
};

export default App;