import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const editImageWithPrompt = async (
  base64ImageData: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    if (response.candidates && response.candidates.length > 0 && response.candidates[0].content.parts) {
      // First, try to find and return an image part from the first candidate.
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
          const base64ImageBytes: string = part.inlineData.data;
          return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
        }
      }
    }

    // If no image is found, check for a text part. This often indicates a safety block or refusal.
    const textResponse = response.text;
    if (textResponse) {
      throw new Error(`L'AI ha rifiutato la richiesta. Motivo: "${textResponse}"`);
    }

    // If no image and no text explanation is found, throw a generic error.
    throw new Error("L'API non ha restituito un'immagine valida. Prova a modificare il prompt.");
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Preserve the specific error message from the try block or a network error.
    if (error instanceof Error) {
      throw error;
    }
    // Fallback for non-Error exceptions.
    throw new Error("Errore durante la comunicazione con il servizio AI. Controlla la console per i dettagli.");
  }
};