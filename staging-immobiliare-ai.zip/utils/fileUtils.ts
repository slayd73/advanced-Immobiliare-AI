
export const fileToBase64 = (file: File): Promise<{ data: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      const [mimeString, base64Data] = result.split(',');
      if (!mimeString || !base64Data) {
        return reject(new Error("Invalid file format for base64 conversion."));
      }
      const mimeType = mimeString.split(':')[1]?.split(';')[0];
       if (!mimeType) {
        return reject(new Error("Could not determine MIME type from file."));
      }
      resolve({ data: base64Data, mimeType });
    };
    reader.onerror = error => reject(error);
  });
};
