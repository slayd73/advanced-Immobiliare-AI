import React from 'react';

const examples = [
  "Stile minimalista, colori neutri e legno chiaro",
  "Arredamento moderno con un divano blu e accenti dorati",
  "Interno rustico con pareti in pietra e travi a vista",
  "Stile bohémien con molte piante, tappeti e cuscini colorati",
  "Un ufficio in casa high-tech con scrivania regolabile e illuminazione a LED",
  "Trasforma il salotto in uno spazio accogliente da baita di montagna",
];

interface PromptExamplesProps {
  onSelectPrompt: (prompt: string) => void;
  disabled?: boolean;
}

export const PromptExamples: React.FC<PromptExamplesProps> = ({ onSelectPrompt, disabled }) => {
  return (
    <div className="mt-4">
      <h4 className="text-xs font-semibold text-slate-400 mb-2">Non sai cosa scrivere? Prova uno di questi:</h4>
      <div className="flex flex-wrap gap-2">
        {examples.map((example) => (
          <button
            key={example}
            onClick={() => onSelectPrompt(example)}
            disabled={disabled}
            className="bg-slate-700 hover:bg-slate-600 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed text-slate-300 text-xs font-medium px-3 py-1.5 rounded-full transition-colors duration-200"
          >
            {example}
          </button>
        ))}
      </div>
    </div>
  );
};
