import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';
import { DownloadIcon } from './icons/DownloadIcon';

interface ImageDisplayProps {
  originalImage: string | null;
  editedImage: string | null;
  isLoading: boolean;
}

const ImagePanel: React.FC<{
  title: string;
  imageUrl: string | null;
  children?: React.ReactNode;
  showDownload?: boolean;
  onDownload?: () => void;
}> = ({ title, imageUrl, children, showDownload, onDownload }) => (
  <div className="flex-1">
    <div className="flex justify-center items-center mb-4 relative px-10">
      <h3 className="text-lg font-semibold text-slate-300 text-center">{title}</h3>
      {showDownload && imageUrl && (
        <button
          onClick={onDownload}
          className="absolute right-0 bg-slate-700 hover:bg-slate-600 p-2 rounded-full transition-colors duration-200"
          aria-label="Scarica immagine modificata"
          title="Scarica immagine modificata"
        >
          <DownloadIcon className="w-5 h-5 text-slate-300" />
        </button>
      )}
    </div>
    <div className="relative aspect-video bg-slate-800 rounded-lg overflow-hidden shadow-inner">
      {imageUrl ? (
        <img src={imageUrl} alt={title} className="w-full h-full object-contain" />
      ) : (
        <div className="w-full h-full flex items-center justify-center text-slate-500">
          {children || 'Nessuna immagine'}
        </div>
      )}
    </div>
  </div>
);


export const ImageDisplay: React.FC<ImageDisplayProps> = ({ originalImage, editedImage, isLoading }) => {
  if (!originalImage && !editedImage && !isLoading) {
    return null;
  }

  const handleDownload = () => {
    if (!editedImage) return;
    const link = document.createElement('a');
    link.href = editedImage;
    link.download = `staging-immobiliare-ai-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-center mb-6 text-slate-200">Risultato</h2>
      <div className="flex flex-col md:flex-row gap-8">
        <ImagePanel title="Originale" imageUrl={originalImage} />
        <ImagePanel
          title="Modificato"
          imageUrl={editedImage}
          showDownload={!!editedImage && !isLoading}
          onDownload={handleDownload}
        >
            {isLoading && <LoadingSpinner />}
        </ImagePanel>
      </div>
    </div>
  );
};