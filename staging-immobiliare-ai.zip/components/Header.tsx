
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-slate-800/50 backdrop-blur-sm shadow-lg sticky top-0 z-10">
      <div className="container mx-auto px-4 py-4">
        <h1 className="text-2xl md:text-3xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-cyan-400">
          Staging Immobiliare AI
        </h1>
        <p className="text-center text-slate-400 mt-1 text-sm md:text-base">
          Trasforma gli interni delle tue proprietà con un click.
        </p>
      </div>
    </header>
  );
};
