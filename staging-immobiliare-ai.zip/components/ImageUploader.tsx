
import React, { useRef, useCallback } from 'react';
import { PhotoIcon } from './icons/PhotoIcon';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  imagePreviewUrl: string | null;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, imagePreviewUrl }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    event.stopPropagation();
    const file = event.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
        onImageUpload(file);
    }
  }, [onImageUpload]);

  const handleDragOver = (event: React.DragEvent<HTMLDivElement>) => {
      event.preventDefault();
      event.stopPropagation();
  };

  return (
    <div className="space-y-2">
       <label className="block text-sm font-medium text-slate-300">
          1. Carica una foto dell'immobile
        </label>
      <div
        className="relative w-full aspect-video border-2 border-dashed border-slate-600 rounded-lg flex flex-col justify-center items-center text-center p-4 cursor-pointer hover:border-indigo-500 hover:bg-slate-700/50 transition-all duration-300"
        onClick={handleClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/png, image/jpeg, image/webp"
        />
        {imagePreviewUrl ? (
          <img src={imagePreviewUrl} alt="Anteprima" className="absolute inset-0 w-full h-full object-cover rounded-lg" />
        ) : (
          <div className="flex flex-col items-center text-slate-400">
            <PhotoIcon className="w-12 h-12 mb-2" />
            <span className="font-semibold">Clicca per caricare o trascina un'immagine</span>
            <span className="text-xs mt-1">PNG, JPG, WEBP</span>
          </div>
        )}
      </div>
    </div>
  );
};
